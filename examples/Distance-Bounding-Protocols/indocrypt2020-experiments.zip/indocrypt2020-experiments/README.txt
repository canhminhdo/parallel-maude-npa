#README#
Here you will find the indications to run all the experiments from the paper Protocol Analysis with Time published in INDOCRYPT 2020.

##Tools##
To launch experiments you will need the Maude programming language and the Maude-NPA protocol analyzer. Both are included in this ZIP file dowloaded from the web page.
However, you can find the latest versions at the following links:

  Maude 3.1: 
  http://maude.cs.illinois.edu/w/index.php/Maude_download_and_installation

  Maude-NPA 3.1.5: 
  http://maude.cs.illinois.edu/w/index.php/Maude_Tools:_Maude-NPA

##Installation##

###Installation Maude 3.1###

This ZIP files included a directory called maude3.1 with version 3.1 of the Maude programming language. This directory includes the following files:
  file.maude
  linear.maude
  machine-int.maude
  maude.[linux64|darwin64]
  metaInterpreter.maude
  model-checker.maude
  prelude.maude
  process.maude
  socket.maude
  smt.maude
  term-order.maude

Maude runs on many Unix variants, including Linux and Mac OSX.
To execute the Mac OS X version of Maude, execute maude.darwin64.
To execute the Linux version of Maude, execute maude.linux64.
You may need to give execution rights to the appropriate Maude executable file.

###Installation Maude-NPA 3.1.5###
There is no installation for Maude-NPA. Just loaded it into Maude before loading any protocol file.

##Usage##

###Loading###

A typical execution session will be as follows:

----------------------------------------------
…~$ maude.linux64
 			\||||||||||||||||||/
		   --- Welcome to Maude ---
		     /||||||||||||||||||\
	     Maude 3.1 built: Oct 12 2020 20:12:31
	     Copyright 1997-2020 SRI International
		   Wed Oct 21 15:04:13 2020
Maude> 
----------------------------------------------

To start Maude-NPA, simply load it as follows:

----------------------------------------------
Maude> load maude-npa.maude 

	    Maude-NPA Version: 3.1.5 (August 9th 2020)
	    with direct composition, irreducibility constraints and time
	    (To be run with Maude 3.0 or above)
	    Copyright (c) 2020, University of Illinois
	    All rights reserved.

 Commands:
 red unification? .           returns the unification algorithm to be used
 red new-strands? .           returns the actual protocol strands
 red displayGrammars .        for generating grammars
 red run(X,Y).                for Y backwards analysis steps for attack pattern X
 red debug(X,Y).              more information than run command
 red digest(X,Y).             less information than run command
 red summary(X,Y).            for summary of analysis steps
 red ids(X,Y).                for set of state ids
 red initials(X,Y).           for showing only initial steps
----------------------------------------------

You can load any protocol (for easier execution move the protocols to the same folder of the Maude-NPA file)

----------------------------------------------
Maude> load brands-chaum.maude
----------------------------------------------

For simplicity, we have included the list of commands to prove or disprove each attack pattern at the end of each protocol file. We have also included the expected output in comments after each attack pattern, so the user could check that the actual output corresponds to the expected output.

To execute and evaluate the attack patterns included in the protocol file,
you need to know its identifier X of the form "ATTACK-STATE(X)".
For example, the brands-chaum file included the Mafia fraud attack as number 1 
and the attack Hijacking as number 2.

###Analyzing###

Among the different Maude-NPA commands, we recommend just the "summary" command,
where the first parameter is the attack identifier and the second one is the depth of the search tree.
For example, the following command asks for the initial attack pattern of the Mafia fraud:

----------------------------------------------
Maude> red summary(1,0) .

reduce in MAUDE-NPA : summary(1, 0) .
rewrites: 2255511 in 3060ms cpu (3060ms real) (737095 rewrites/second)
result Summary: States>> 1 Solutions>> 0
----------------------------------------------

In this output, the word "States" indicates the number of states at the frontier of the search depth,
and the word "Solutions" indicates the number of initial states at the frontier of this depth.

For example, the following command asks for depth 4 of the initial attack pattern of the Mafia fraud:

----------------------------------------------
reduce in MAUDE-NPA : summary(1, 4) .
rewrites: 298322 in 640ms cpu (639ms real) (466128 rewrites/second)
result Summary: States>> 0 Solutions>> 0
----------------------------------------------

The previous output indicates that no state is found. That is, Maude-NPA has explored all the possible 
backwards transitions of the attack pattern and has not found an initial state. 

A different output is given for the attack 2 (Hijacking)

----------------------------------------------
reduce in MAUDE-NPA : summary(2, 6) .
rewrites: 289507 in 348ms cpu (351ms real) (831916 rewrites/second)
result Summary: States>> 1 Solutions>> 1
----------------------------------------------

The previous output shows that an initial state has found for this attack pattern. 
If you want to see this state, type the next command red initials(2,6) .

----------------------------------------------
Maude> red initials(2,6) .
reduce in MAUDE-NPA : initials(2, 6) .
rewrites: 370 in 0ms cpu (1ms real) (~ rewrites/second)
result ShortIdSystem: < 1 . 2 . 7 . 6{1} . 3{1} . 1 . 1 > (
:: nil ::
[ nil | 
   -((n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh)
      @ i : #2:Real -> #3:NameTimeSet # i : #4:Real), (#4:Real === #2:Real +=+ 0/1 and 0/1 >= 0/1), 
   +(sign(i, (n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh))
      @ i : #4:Real -> a : #5:Real), nil]  & 
:: nil ::
[ nil | 
   -(n(a, #0:Fresh) * n(b, #1:Fresh)
      @ b : #6:Real -> a : #7:Real # i : #8:Real), (#8:Real === #6:Real +=+ d(b, i) and d(b, i) >= 0/1), 
   -(n(a, #0:Fresh)
      @ a : #9:Real -> b : #6:Real # i : #10:Real), (#10:Real === #9:Real +=+ d(a, i) and d(a, i) >= 0/1), (#2:Real >= #8:Real
    and #2:Real >= #10:Real), 
   +((n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh)
      @ i : #2:Real -> #3:NameTimeSet # i : #4:Real), nil]  & 
:: #0:Fresh ::
[ nil | 
   -(commit(n(b, #1:Fresh), s(b, #11:Fresh))
      @ b : #12:Real -> a : #9:Real # i : #13:Real), (#9:Real === #12:Real +=+ #14:Real and #14:Real > 0/1), 
   +(n(a, #0:Fresh)
      @ a : #9:Real -> b : #6:Real # i : #10:Real), 
   -(n(a, #0:Fresh) * n(b, #1:Fresh)
      @ b : #6:Real -> a : #7:Real # i : #8:Real), (#7:Real === #6:Real +=+ #14:Real and #14:Real > 0/1), ((#7:Real -=-
    #9:Real) <= (2/1 *=* #14:Real) and #14:Real > 0/1), 
   -(s(b, #11:Fresh)
      @ b : #6:Real -> a : #15:Real # i : #16:Real), (#15:Real === #6:Real +=+ #14:Real and #14:Real > 0/1), 
   yes eq yes, 
   -(sign(i, (n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh))
      @ i : #4:Real -> a : #5:Real), (#5:Real === #4:Real +=+ d(a, i) and d(a, i) > 0/1), nil]  & 
:: #1:Fresh,#11:Fresh ::
[ nil | 
   +(commit(n(b, #1:Fresh), s(b, #11:Fresh))
      @ b : #12:Real -> a : #9:Real # i : #13:Real), 
   -(n(a, #0:Fresh)
      @ a : #9:Real -> b : #6:Real # i : #10:Real), (#6:Real === #9:Real +=+ #14:Real and #14:Real > 0/1), 
   +(n(a, #0:Fresh) * n(b, #1:Fresh)
      @ b : #6:Real -> a : #7:Real # i : #8:Real), 
   +(s(b, #11:Fresh)
      @ b : #6:Real -> a : #15:Real # i : #16:Real), nil] )
| 
(n(a, #0:Fresh)
 @ a : #9:Real -> b : #6:Real # i : #10:Real) !inI,
(s(b, #11:Fresh)
 @ b : #6:Real -> a : #15:Real # i : #16:Real) !inI,
(sign(i, (n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh))
 @ i : #4:Real -> a : #5:Real) !inI,
((n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh)
 @ i : #2:Real -> #3:NameTimeSet # i : #4:Real) !inI,
(commit(n(b, #1:Fresh), s(b, #11:Fresh))
 @ b : #12:Real -> a : #9:Real # i : #13:Real) !inI,
(n(a, #0:Fresh) * n(b, #1:Fresh)
 @ b : #6:Real -> a : #7:Real # i : #8:Real) !inI,
smt(#9:Real === #12:Real +=+ #14:Real and #14:Real > 0/1 and (#6:Real === #9:Real +=+ #14:Real and #14:Real > 0/1 and (#8:Real
    === #6:Real +=+ d(b, i) and d(b, i) >= 0/1 and (#10:Real === #9:Real +=+ d(a, i) and d(a, i) >= 0/1 and (#2:Real >= #8:Real
    and #2:Real >= #10:Real and (#4:Real === #2:Real +=+ 0/1 and 0/1 >= 0/1 and (#7:Real === #6:Real +=+ #14:Real and #14:Real
    > 0/1 and ((#7:Real -=- #9:Real) <= (2/1 *=* #14:Real) and #14:Real > 0/1 and (#15:Real === #6:Real +=+ #14:Real and
    #14:Real > 0/1 and (#5:Real === #4:Real +=+ d(a, i) and d(a, i) > 0/1))))))))))
| 
+(commit(n(b, #1:Fresh), s(b, #11:Fresh))
   @ b : #12:Real -> a : #9:Real # i : #13:Real), 
-(commit(n(b, #1:Fresh), s(b, #11:Fresh))
   @ b : #12:Real -> a : #9:Real # i : #13:Real), 
+(n(a, #0:Fresh)
   @ a : #9:Real -> b : #6:Real # i : #10:Real), 
-(n(a, #0:Fresh)
   @ a : #9:Real -> b : #6:Real # i : #10:Real), 
+(n(a, #0:Fresh) * n(b, #1:Fresh)
   @ b : #6:Real -> a : #7:Real # i : #8:Real), 
-(n(a, #0:Fresh) * n(b, #1:Fresh)
   @ b : #6:Real -> a : #7:Real # i : #8:Real), 
-(n(a, #0:Fresh)
   @ a : #9:Real -> b : #6:Real # i : #10:Real), 
+((n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh)
   @ i : #2:Real -> #3:NameTimeSet # i : #4:Real), 
-((n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh)
   @ i : #2:Real -> #3:NameTimeSet # i : #4:Real), 
+(sign(i, (n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh))
   @ i : #4:Real -> a : #5:Real), 
+(s(b, #11:Fresh)
   @ b : #6:Real -> a : #15:Real # i : #16:Real), 
-(n(a, #0:Fresh) * n(b, #1:Fresh)
   @ b : #6:Real -> a : #7:Real # i : #8:Real), 
-(s(b, #11:Fresh)
   @ b : #6:Real -> a : #15:Real # i : #16:Real), 
-(sign(i, (n(a, #0:Fresh) * n(b, #1:Fresh)) ; n(a, #0:Fresh))
   @ i : #4:Real -> a : #5:Real)
| 
nil
----------------------------------------------

##Manual##

If you need more help with Maude or Maude-NPA please follow the manual, 
Maude : http://maude.lcc.uma.es/maude31-manual-html/maude-manual.html
Maude-NPA : http://maude.cs.illinois.edu/w/index.php/Maude_Tools:_Maude-NPA

##